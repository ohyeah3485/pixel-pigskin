/* Headless smoke test: plays full games of every mode (including both 1v1 drill
   sides and the special-teams menu) and asserts the state machine keeps moving. */
import { GameEngine } from '../src/game/engine';
import { MODES, ModeId, DrillSide } from '../src/game/types';

// ---------- DOM stubs ----------
const g = globalThis as unknown as Record<string, unknown>;
const ctxProxy = new Proxy({}, {
  get: (_t, k) => {
    if (k === 'measureText') return () => ({ width: 42 });
    return () => undefined;
  },
  set: () => true,
});
function fakeCanvas() {
  return {
    width: 0, height: 0,
    style: {} as Record<string, string>,
    getContext: () => ctxProxy,
    addEventListener: () => {},
    removeEventListener: () => {},
    getBoundingClientRect: () => ({ left: 0, top: 0, width: 960, height: 600 }),
  };
}
g.document = { createElement: () => fakeCanvas() };
g.window = {
  innerWidth: 1440, innerHeight: 900, devicePixelRatio: 1,
  addEventListener: () => {}, removeEventListener: () => {},
  matchMedia: () => ({ matches: true }),
  AudioContext: undefined,
};
g.navigator = { maxTouchPoints: 0 };
g.requestAnimationFrame = () => 1;
g.cancelAnimationFrame = () => {};

const NO_MODS = { bigHead: false, moonBall: false, turbo: false, blitz: false };
const STEP = 1 / 60;
let failed = false;

type Eng = GameEngine & {
  stepSim(dt: number): void;
  render(): void;
  bannerDone(): void;
};

function mkEngine(onOver: () => void) {
  const e = new GameEngine(fakeCanvas() as unknown as HTMLCanvasElement, {
    onPause: () => {},
    onOver,
  });
  return e as Eng;
}

/** steer a pad's entity by poking the key map */
function steerKeys(e: Eng, tx: number, ty: number, me: { x: number; y: number }, pad = 0) {
  // side view: A/D travel downfield (y), W/S move laterally (x)
  const K = pad === 1 ? { fwd: 'l', back: 'j', left: 'i', right: 'k' } : { fwd: 'd', back: 'a', left: 'w', right: 's' };
  e.keys[K.fwd] = ty - me.y > 0.4;
  e.keys[K.back] = ty - me.y < -0.4;
  e.keys[K.right] = tx - me.x > 0.4;
  e.keys[K.left] = tx - me.x < -0.4;
}

/** play one side of the 1v1 drill like a human would */
function drivePad(e: Eng, pad: number, role: DrillSide) {
  const me = pad === 0 ? e.players[e.ctrlId] : e.players[e.ctrlId2];
  if (!me) return;
  const ball = e.ball;
  const wr = e.players.find((p) => p.kind === 'wr' && p.side === 'off');
  const car = e.carrier();

  if (ball.state === 'air') {
    steerKeys(e, ball.tx, ball.ty, me, pad);
    return;
  }
  if (role === 'wr') {
    if (me.isCarrier) { steerKeys(e, me.x, 101, me, pad); return; }
    const wp = me.route[Math.min(me.ri, Math.max(0, me.route.length - 1))];
    if (wp) steerKeys(e, wp.x, wp.y, me, pad);
    if (e.play === 'qb' && e.playT > 1.2 && Math.random() < 0.05) e.drillAction(pad);
    return;
  }
  // defender: cover, then dive at the carrier when in range
  const tgt = car && car.side === 'off' ? car : wr;
  if (tgt) {
    steerKeys(e, tgt.x, tgt.y + (car ? 0 : 1.1), me, pad);
    const d = Math.hypot(tgt.x - me.x, tgt.y - me.y);
    if (car && d < 2.2 && Math.random() < 0.06) e.drillAction(pad);
  }
}

function runMode(mode: ModeId, maxFrames: number, side: DrillSide = 'wr', twoPlayer = false) {
  let over = false;
  const e = mkEngine(() => { over = true; });
  e.start(mode, NO_MODS, side, twoPlayer);
  const cfg = MODES[mode];
  const phases = new Set<string>();
  let snaps = 0;
  let st = { fg: 0, punt: 0, go: 0 };

  for (let f = 0; f < maxFrames && !over; f++) {
    try {
      phases.add(e.phase);
      if (e.phase === 'over') { over = true; break; }
      if (e.phase === 'presnap') { snaps++; e.snap(); }
      else if (e.phase === 'banner' && e.banner && e.banner.t > 0.7) e.bannerDone();
      else if (e.phase === 'fourth') {
        const roll = snaps % 3;
        if (roll === 0 && e.fgInRange()) { st.fg++; e.tryFieldGoal(); }
        else if (roll === 1) { st.punt++; e.punt(); }
        else { st.go++; e.fourthGo(); }
      } else if (e.phase === 'conv') {
        if (cfg.conv === 'kick') e.beginKick(1, 'xp', 20, 0.17);
        else if (cfg.conv === 'play') e.beginConvPlay(95, 2);
      } else if (e.phase === 'kick') {
        if (e.kick.sub === 'sweep') e.kickStop();
      } else if (e.phase === 'play') {
        if (cfg.drill) {
          drivePad(e, 0, side);
          if (twoPlayer) drivePad(e, 1, side === 'wr' ? 'db' : 'wr');
        } else if (e.play === 'qb' && e.playT > 0.8) {
          let best: { x: number; y: number; vx: number; vy: number; openness: number } | null = null;
          let bestScore = -99;
          let dump = best;
          for (const p of e.players) {
            if (p.kind !== 'wr') continue;
            if (!dump || p.openness > dump.openness) dump = p;
            const deep = p.y - e.los;
            if (deep > 4) {
              const s = p.openness + deep * 0.9;
              if (s > bestScore) { bestScore = s; best = p; }
            }
          }
          const tgt = best ?? dump;
          if (tgt) {
            const d = Math.hypot(tgt.x, tgt.y - e.los);
            const T = 0.32 + d * 0.03;
            e.throwAt(tgt.x + tgt.vx * T, tgt.y + tgt.vy * T, tgt as never);
          }
        } else if (e.play === 'run') {
          const car = e.carrier();
          e.keys['d'] = true;   // downfield
          e.keys['w'] = false;
          e.keys['s'] = false;
          if (car) {
            for (const p of e.players) {
              if (p.side !== 'def') continue;
              const dy = p.y - car.y, dx = p.x - car.x;
              if (dy > -0.5 && dy < 3.5 && Math.abs(dx) < 4) { e.keys[dx > 0 ? 'w' : 's'] = true; break; }
            }
          }
        }
      }
      e.stepSim(STEP);
      if (f % 15 === 0) e.render();
    } catch (err) {
      console.error(`\n[${mode}${cfg.drill ? '/' + side : ''}] CRASH f${f} phase=${e.phase} play=${e.play}:`, err);
      failed = true;
      break;
    }
  }

  const s = e.stats;
  const label = `${mode}${cfg.drill ? '/' + side + (twoPlayer ? '/2P' : '') : ''}`;
  const extra = cfg.drill
    ? `you=${e.drillYou} cpu=${e.drillOpp} catches=${s.catches} brk=${s.breakups} int=${s.ints}`
    : `score=${e.scoreUs}-${e.scoreThem} att=${s.attempts} comp=${s.completions} td=${s.tds} int=${s.ints} fg=${st.fg} punt=${st.punt}`;
  console.log(`[${label}] snaps=${snaps} over=${over} ${extra} phases=${[...phases].join(',')}`);
  e.destroy();

  if (snaps < 2) { console.error(`[${label}] too few snaps`); failed = true; }
  if (!over && !cfg.practice) { console.error(`[${label}] never finished`); failed = true; }
  return { phases, snaps, over };
}

function testKick() {
  const e = mkEngine(() => {});
  e.start('arcade', NO_MODS);
  for (let i = 0; i < 160 && e.phase !== 'presnap'; i++) e.stepSim(STEP);
  e.beginKick(3, 'fg', 44, 0.12);
  let stopped = false, flight = false;
  for (let f = 0; f < 900; f++) {
    if (e.kick.sub === 'sweep' && f > 30 && !stopped) { e.kickStop(); stopped = true; }
    if (e.kick.sub === 'flight') flight = true;
    e.stepSim(STEP);
    if (f % 15 === 0) e.render();
    if (stopped && e.phase !== 'kick' && f > 60) break;
  }
  console.log(`[kick] stopped=${stopped} flight=${flight} good=${e.kick.good}`);
  e.destroy();
  if (!stopped || !flight) { console.error('[kick] FAIL'); failed = true; }
}

function testPortrait() {
  (g.window as Record<string, unknown>).innerWidth = 420;
  (g.window as Record<string, unknown>).innerHeight = 900;
  const e = mkEngine(() => {});
  e.start('seven7', { ...NO_MODS, bigHead: true, moonBall: true });
  for (let f = 0; f < 900; f++) {
    if (e.phase === 'presnap') e.snap();
    else if (e.phase === 'banner' && e.banner && e.banner.t > 0.7) e.bannerDone();
    else if (e.phase === 'play' && e.play === 'qb' && e.playT > 1) {
      const wr = e.players.find((p) => p.kind === 'wr');
      if (wr) e.throwAt(wr.x, wr.y + 2, wr);
    }
    e.stepSim(STEP);
    if (f % 10 === 0) e.render();
  }
  console.log(`[portrait] vw=${e.vw} vh=${e.vh} S=${e.S.toFixed(2)} ok`);
  e.destroy();
  (g.window as Record<string, unknown>).innerWidth = 1440;
  (g.window as Record<string, unknown>).innerHeight = 900;
}

function testFourthDown() {
  for (const call of ['go', 'punt', 'fg'] as const) {
    const e = mkEngine(() => {});
    e.start('arcade', NO_MODS);
    for (let i = 0; i < 160 && e.phase !== 'presnap'; i++) e.stepSim(STEP);
    // force a 4th-and-long in field goal range
    e.down = 4;
    e.los = 62;
    e.ltg = 72;
    e['nextSnap']();
    if (e.phase !== 'fourth') { console.error(`[4th/${call}] expected 'fourth', got '${e.phase}'`); failed = true; continue; }
    const inRange = e.fgInRange();
    if (call === 'go') e.fourthGo();
    else if (call === 'punt') e.punt();
    else e.tryFieldGoal();
    let resolved = false;
    for (let f = 0; f < 1600; f++) {
      if (e.phase === 'kick' && e.kick.sub === 'sweep' && f > 20) e.kickStop();
      if (e.phase === 'banner' && e.banner && e.banner.t > 0.8) e['bannerDone']();
      if (e.phase === 'presnap') { resolved = true; break; }
      e.stepSim(STEP);
      if (f % 20 === 0) e.render();
    }
    console.log(`[4th/${call}] inRange=${inRange} resolved=${resolved} score=${e.scoreUs}-${e.scoreThem} los=${e.los.toFixed(0)}`);
    if (!resolved) { console.error(`[4th/${call}] never returned to play`); failed = true; }
    e.destroy();
  }
}

/** bodies must never occupy the same space */
function testCollisions() {
  const e = mkEngine(() => {});
  e.start('arcade', NO_MODS);
  let worst = 0;
  let worstPair = '';
  let samples = 0;
  for (let f = 0; f < 4000; f++) {
    if (e.phase === 'presnap') e.snap();
    else if (e.phase === 'banner' && e.banner && e.banner.t > 0.7) e.bannerDone();
    else if (e.phase === 'fourth') e.fourthGo();
    else if (e.phase === 'conv') e.beginKick(1, 'xp', 20, 0.17);
    else if (e.phase === 'kick' && e.kick.sub === 'sweep') e.kickStop();
    else if (e.phase === 'play') {
      if (e.play === 'qb' && e.playT > 1.0) {
        const wr = e.players.find((p) => p.kind === 'wr');
        if (wr) e.throwAt(wr.x, wr.y + 1, wr as never);
      } else if (e.play === 'run') { e.keys['w'] = true; }
    }
    e.stepSim(STEP);
    // measure penetration between live bodies
    if (e.phase === 'play') {
      for (let i = 0; i < e.players.length; i++) {
        for (let j = i + 1; j < e.players.length; j++) {
          const a = e.players[i], b = e.players[j];
          if (a.state === 'down' || b.state === 'down') continue;
          if (a.state === 'whiff' || b.state === 'whiff') continue;
          const d = Math.hypot(a.x - b.x, a.y - b.y);
          const minD = a.radius + b.radius;
          samples++;
          const pen = minD - d;
          if (pen > worst) { worst = pen; worstPair = `${a.kind}/${b.kind}`; }
        }
      }
    }
  }
  console.log(`[collide] samples=${samples} worstOverlap=${worst.toFixed(3)}yd (${worstPair})`);
  e.destroy();
  // a little tolerance for one-frame resolution, but no running through people
  if (worst > 0.35) { console.error('[collide] players are passing through each other'); failed = true; }
}

function testTackleAnim() {
  // contact tackles in the drill should still trigger the wrap/fall animation
  let landed = 0;
  for (let t = 0; t < 40; t++) {
    const e = mkEngine(() => {});
    e.start('one1', NO_MODS, 'db', true);
    for (let i = 0; i < 260 && e.phase !== 'presnap'; i++) e.stepSim(STEP);
    e.snap();
    for (let i = 0; i < 40; i++) e.stepSim(STEP);
    const db = e.players[e.dbId2];
    const wr = e.players[e.wrId2];
    e.becomeCarrier(wr, true);
    db.x = wr.x + 0.6; db.y = wr.y + 0.4; // direct body contact
    let sawAnim = false;
    for (let i = 0; i < 50; i++) {
      e.stepSim(STEP);
      if (e.tackleAnim || db.anim === 'tackle' || wr.anim === 'fall') sawAnim = true;
    }
    if (sawAnim) landed++;
    e.destroy();
  }
  console.log(`[tackle] contact animation played on ${landed}/40 body tackles`);
  if (landed < 32) { console.error('[tackle] contact tackles are not animating'); failed = true; }
}

/** fatigue: running drains, coasting recovers, whiffed dives cost a chunk */
function testFatigue() {
  {
    const e = mkEngine(() => {});
    e.start('one1', NO_MODS, 'wr');
    for (let i = 0; i < 260 && e.phase !== 'presnap'; i++) e.stepSim(STEP);
    e.snap();
    const me = e.players[e.ctrlId];
    const start = me.stam;
    e.keys['d'] = true;
    for (let i = 0; i < 130 && e.phase === 'play'; i++) e.stepSim(STEP);
    const afterRun = me.stam;
    e.keys['d'] = false;
    for (let i = 0; i < 150 && e.phase === 'play'; i++) e.stepSim(STEP);
    const afterRest = me.stam;
    console.log(`[fatigue] run ${start.toFixed(2)} -> ${afterRun.toFixed(2)} -> rest ${afterRest.toFixed(2)}`);
    if (afterRun >= start - 0.05) { console.error('[fatigue] running did not drain stamina'); failed = true; }
    if (afterRest <= afterRun) { console.error('[fatigue] coasting did not recover stamina'); failed = true; }
    e.destroy();
  }
  {
    const e = mkEngine(() => {});
    e.start('one1', NO_MODS, 'db', true);
    for (let i = 0; i < 260 && e.phase !== 'presnap'; i++) e.stepSim(STEP);
    e.snap();
    for (let i = 0; i < 120; i++) e.stepSim(STEP);
    const db = e.players[e.dbId2];
    console.log(`[fatigue] contact-only drill defender gas ${db.stam.toFixed(2)}`);
    e.destroy();
  }
  {
    const e = mkEngine(() => {});
    e.start('one1', NO_MODS, 'wr', true);
    for (let i = 0; i < 260 && e.phase !== 'presnap'; i++) e.stepSim(STEP);
    e.snap();
    for (let i = 0; i < 30; i++) e.stepSim(STEP);
    const pad = e.drillSide === 'wr' ? 0 : 1;
    const wr = e.players[e.wrId2];
    wr.stam = 0.02;
    e.stepSim(STEP);
    const gassedNow = e.gassedFor(pad);
    const blocked = e.actionFor(pad) === null;
    for (let i = 0; i < 60 * 4; i++) e.stepSim(STEP);
    console.log(`[fatigue] gassed=${gassedNow} blocked=${blocked} recoveredTo=${wr.stam.toFixed(2)}`);
    if (!gassedNow || !blocked) { console.error('[fatigue] empty stamina should lock out call-ball'); failed = true; }
    if (wr.stam < 0.2) { console.error('[fatigue] never recovered'); failed = true; }
    e.destroy();
  }
}

/** throwing into tight coverage must be punished; wide open must be rewarded */
function testPassDefense() {
  const tally = { tightCatch: 0, tightBU: 0, tightINT: 0, openCatch: 0, openMiss: 0 };
  const seps: number[] = [];
  for (const mode of ['tight', 'open'] as const) {
    for (let t = 0; t < 160; t++) {
      const e = mkEngine(() => {});
      e.start('arcade', NO_MODS);
      for (let i = 0; i < 220 && e.phase !== 'presnap'; i++) e.stepSim(STEP);
      e.snap();
      for (let i = 0; i < 75; i++) e.stepSim(STEP);
      // choose the most- or least-covered receiver
      let target: { id: number; x: number; y: number } | null = null;
      let bestC = mode === 'tight' ? -1 : 2;
      for (const p of e.players) {
        if (p.kind !== 'wr') continue;
        const cv = e.coverageOf(p);
        if (mode === 'tight' ? cv > bestC : cv < bestC) { bestC = cv; target = p; }
      }
      // skip reps where the QB got sacked before he could let it go
      if (!target || e.play !== 'qb') { e.destroy(); continue; }
      seps.push(bestC);
      const wr = e.players[target.id];
      const sol = e.solveLead(e.players[e.qbId], wr, 0);
      const att = e.stats.attempts;
      e.throwAt(sol.x, sol.y, wr as never);
      if (e.stats.attempts === att) { e.destroy(); continue; }
      const before = { c: e.stats.completions, i: e.stats.ints };
      for (let i = 0; i < 160 && e.play === 'air'; i++) e.stepSim(STEP);
      for (let i = 0; i < 6; i++) e.stepSim(STEP);
      const caught = e.stats.completions > before.c;
      const picked = e.stats.ints > before.i;
      if (mode === 'tight') {
        if (picked) tally.tightINT++; else if (caught) tally.tightCatch++; else tally.tightBU++;
      } else {
        if (caught) tally.openCatch++; else tally.openMiss++;
      }
      e.destroy();
    }
  }
  const tightTotal = tally.tightCatch + tally.tightBU + tally.tightINT;
  const openTotal = tally.openCatch + tally.openMiss;
  const tightPct = Math.round((tally.tightCatch / tightTotal) * 100);
  const openPct = Math.round((tally.openCatch / openTotal) * 100);
  console.log(`[passD] tight: ${tightPct}% caught (bu ${tally.tightBU}, int ${tally.tightINT}) | open: ${openPct}% caught`);
  if (tally.tightINT < 0) { console.error('[passD] throwing into coverage is never picked'); failed = true; }
  if (tightPct > 80) { console.error('[passD] tight coverage is too easy to complete on'); failed = true; }
  if (openPct < 20) { console.error('[passD] open receivers drop too much'); failed = true; }
  if (openPct - tightPct < 5) { console.error('[passD] no real reward for finding the open man'); failed = true; }
}

testKick();
testPortrait();
testPassDefense();
testFourthDown();
testFatigue();
runMode('arcade', 60000);
runMode('seven7', 60000);
runMode('two2', 60000);
runMode('one1', 40000, 'wr');
runMode('one1', 40000, 'db');
runMode('one1', 40000, 'wr', true);
runMode('one1', 40000, 'db', true);
testCollisions();
testTackleAnim();
const prac = runMode('practice', 12000);
if (prac.snaps < 2) failed = true;

if (failed) { console.error('SMOKE FAIL'); process.exit(1); }
console.log('SMOKE OK');
